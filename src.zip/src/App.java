public class App {
    public static void main(String[] args) throws Exception {

        Springerproblem problem1 = new Springerproblem(6, 6, false, false, 0, 0);
        problem1.run();
        // for (int i = 0; i < 5; i++) {
        // for (int j = 0; j < 5; j++) {
        // Springerproblem problem1 = new Springerproblem(5, 5, false, false, j, i);
        // problem1.run();
        // }
        // }
        // for (int i = 0; i < 5; i++) {
        // for (int j = 0; j < 5; j++) {
        // Springerproblem problem1 = new Springerproblem(5, 5, false, true, j, i);
        // problem1.run();
        // }
        // }
        // System.out.println("");
        // for (int i = 0; i < 5; i++) {
        // for (int j = 0; j < 5; j++) {
        // Springerproblem problem2 = new Springerproblem(5, 5, false, false, j, i);
        // problem2.run();
        // }
        // }
        // System.out.println("");
        // for (int i = 0; i < 5; i++) {
        // for (int j = 0; j < 5; j++) {
        // Springerproblem problem3 = new Springerproblem(5, 5, true, false, j, i);
        // problem3.run();
        // }
        // }
    }
}
